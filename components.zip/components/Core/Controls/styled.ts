import styled from '@emotion/styled';

export const Container = styled.div`
  background-color: white;
  height: 60px;
`;
