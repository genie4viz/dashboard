import { css } from '@emotion/core';

export const BarStyle = (theme: any) => css`
  border: 1px solid ${theme.color.grayDisabled};
`;
