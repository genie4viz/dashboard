import { css } from 'emotion';

export const FixedTopLeftGridStyle = (theme: any) => css`
  display: block;
  z-index: 1000;
`;
